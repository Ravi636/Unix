#include        <pwd.h>
#include        <stdio.h>
#include        <sys/types.h>
#include        <dirent.h>
#include        <sys/stat.h>
#include        <string.h>


char *uid_to_name( uid_t );


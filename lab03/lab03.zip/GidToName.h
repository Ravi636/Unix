#include        <grp.h>
#include        <stdio.h>
#include        <sys/types.h>
#include        <dirent.h>
#include        <sys/stat.h>
#include        <string.h>



char *gid_to_name( gid_t );




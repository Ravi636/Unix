#include <stdio.h>
#include <curses.h>
#include <math.h>
#include <unistd.h>
#define PI 3.14159265

int main() {
    int i;
    initscr();
    clear();

    int max_x, max_y;
    getmaxyx(stdscr, max_y, max_x);
    double center_x = max_x / 2.0;
    double amplitude = center_x / 2.0;

    double gravity = 0.1;

    for (i = 0; i < LINES; i++) {
        double offset = amplitude * cos(2.0 * PI * i / (double) LINES);
        int x = center_x + (int) offset;

        double scaling_factor = 1.0 + (1.0 + 4  * pow( fabs(center_x - x) / center_x, 2.0));
        double distance_factor = sqrt((double)(max_y - i) / max_y);
        move(i, x);
        if (i % 2 == 1) {
            standout();
        }
        addstr("Hello, world");
        if (i % 2 == 1) {
            standend();
        }
        refresh();

        usleep((useconds_t) (scaling_factor * distance_factor * 90000));

        move(i, x);
        addstr(" ");

        gravity += 0.1;
        int y = i + (int) gravity;
        if (y >= LINES) {
            int k, j;
            for (k = 0; k < 9; k++) {
                for (j = 0; j < 9; j++) {
                    move(y - k, x + j - 6);
                    addch("Hello, world"[k]);
                    refresh();
                    usleep(50000);
                }
            }
        }
    }

    endwin();
    return 0;
}


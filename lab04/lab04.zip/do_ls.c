#include	<stdlib.h>
#include	<string.h> 
#include	<stdio.h>
#include	<dirent.h>
#include        <sys/types.h>
#include        <sys/stat.h>



void do_ls( char dirname[], int subdir )
/*
 *	list files in directory called dirname
 */
{
	DIR		*dir_ptr;		/* the directory */
	struct dirent	*direntp;		/* each entry	 */
	char		*fullpath;

	fullpath = (char *)malloc(strlen(dirname) + 1 + MAXNAMLEN + 1);
	if ( ( dir_ptr = opendir( dirname ) ) == NULL )
		fprintf(stderr,"ls2: cannot open %s\n", dirname);
	else
	{
		while ( ( direntp = readdir( dir_ptr ) ) != NULL ){
			sprintf(fullpath,"%s/%s",dirname,direntp->d_name);
			dostat( fullpath, direntp->d_name );
		}



                if(subdir == 1){
                        rewinddir(dir_ptr);
                        //run while no more dirs are found
                        while(( direntp = readdir( dir_ptr)) != NULL){
          			//if file is current or preveus dir then skip them
                        	if(strcmp(".", direntp -> d_name) == 0 || strcmp("..", direntp -> d_name) == 0){
         				continue;
                        	}// end if
                		
				//prints current dir name / path name
                        	sprintf(fullpath, "%s/%s", dirname, direntp -> d_name);
                       		
				//checks if file path refers to a dir and if true then enter that dir
                        	if(isadir(fullpath)){
                                                        	                                                                                                                                                                                                                                                                 printf("\n");
                 		   do_ls(fullpath, subdir);
                        
                        	}//end if
                        
                                                                                                                                                                                                                                                                                                                       }// end while
                        
                                                                                                                                                                                                                                                                                                               }// end if
                        
                        
                                                                                                                                                                                                                                                                                                              free(fullpath);
                        
                        
		closedir(dir_ptr);
	}
}

/** sol03.11.c 
 ** ------------------------------------------------------------
	A corrected version of ls2.c 
	is: sol03.11.c.
	This program combines the directory name with the filename
	as an argument to stat so stat can find the file.
	The listing only shows the filename, though.

 ** ------------------------------------------------------------
 **
 **
 *
 * ls2.c - corrected
 *
 *	purpose  list contents of directory or directories
 *	action   if no args, use .  else list files in args
 *	note     uses stat and pwd.h and grp.h 
 *	
 *	build: cc sol03.11.c -o sol03.11
 */
#include	<stdio.h>
#include	<stdlib.h>
#include	<sys/types.h>
#include	<dirent.h>
#include	<string.h>
#include	<sys/stat.h>
#include        "do_ls.h"
#include        "dostat.h"
#include        "gid_to_name.h"
#include        "mode_to_letters.h"
#include        "show_file_info.h"
#include	"uid_to_name.h"


main(int ac, char *av[])
{
	
	int files = 0;
        int Rflag = 0;

                //check the type of command inputed by the user
                while ( --ac ){
                	 //if command contains -R then set -R check to true
               		if (strcmp("-R", *++av) == 0){
                        	Rflag = 1;
                	}else{
                	//only prints files in the current directory
                	do_ls( *av, Rflag );
               		files = 1;
                
                	}// end if
                }// end while                                                                                                                              
		
		if (files == 0){
                
	        	do_ls(".", Rflag);
                
                 }// end if
                                                                                                                                                                                                                                                                                              }

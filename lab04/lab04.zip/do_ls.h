#ifndef do_ls_H
#define do_ls_H

void do_ls(char[], int subdir);

#endif


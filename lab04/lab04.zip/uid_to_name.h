#ifndef uid_to_name_H
#define uid_to_name_H

char *uid_to_name(uid_t);

#endif


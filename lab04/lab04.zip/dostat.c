#include        <sys/stat.h>

void dostat( char *fullpath, char *filename )
{
	struct stat info;

	if ( stat(fullpath, &info) == -1 )		/* cannot stat	 */
		perror(filename);			/* say why	 */
	else					/* else show info	 */
		show_file_info(filename, &info);
}


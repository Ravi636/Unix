#ifndef show_file_info_H
#define show_file_info_H

void show_file_info(char *, struct stat *);

#endif


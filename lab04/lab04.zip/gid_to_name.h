#ifndef gid_to_name_H
#define gid_to_name_H

char *gid_to_name(gid_t);

#endif


#ifndef dostat_H
#define dostat_H

void dostat(char *,char *);

#endif

